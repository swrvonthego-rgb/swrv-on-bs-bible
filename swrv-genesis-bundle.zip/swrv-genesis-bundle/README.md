# SWRV Kingdom — Genesis Multi-Source Study

A self-contained, offline-first Bible study tool for the book of Genesis.

## What's inside

- **All 50 chapters of Genesis** — 1,344 verses
- **Tanakh JPS 1917** — every verse (clean, public domain)
- **Amplified Bible** — parallel reading on 516 verses
- **Septuagint (Brenton LXX)** — 32 key verses (creation, fall, Abrahamic call)
- **Strong's Concordance** — 45 Hebrew word entries with definitions, transliterations, cross-references
- **Source Variants** — hand-curated notes on theologically significant verses (Gen 1:1, 1:2, 1:26, 2:7, 3:15, 12:3, 22:18)
- **Reading music** — 3 ambient tracks for study atmosphere
- **3 themes** — Parchment / Stone / High Contrast
- **Full keyboard navigation** — arrow keys, M for music, Esc to close

## How to use

### Option 1 — Just open the file
Open `SWRV_Genesis_Study.html` in any browser. It works.

### Option 2 — Install as an app (PWA)
1. Host the files on any web server (or GitHub Pages)
2. Visit the URL on your phone
3. Browser menu → "Add to Home Screen"
4. Now it lives on your phone like a native app, works offline

### Option 3 — Deploy to GitHub Pages
1. Upload these files to a GitHub repo
2. Settings → Pages → Source: main branch
3. Visit `https://YOUR-USERNAME.github.io/REPO-NAME/`

## Files

| File | Purpose |
|---|---|
| `index.html` | Main entry (same as Genesis study) |
| `SWRV_Genesis_Study.html` | The standalone study tool |
| `manifest.json` | PWA installation config |
| `icon.svg` | App icon |
| `sw.js` | Service worker (offline caching) |

## Built with

- Tanakh JPS 1917 (public domain)
- Brenton Septuagint 1851 (public domain)
- Amplified Bible © Lockman Foundation (limited fair use)
- Strong's Concordance (public domain)

## Vision

> "This information should have never been sold. I want people to have knowledge because I love them."  
> — Zion Birdsong

Built to be free forever, offline-first, accessible to anyone with a browser.

